<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Database\Eloquent\Model;
const PAGING_COUNT = 50;
/**
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
|
| Here is where you can register admin routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

Route::group(['namespace'=>'Admin','prefix'=>'admin'],function(){
    Route::get('/','AdminController@dashboard')->name('admin.dashboard');
    Route::get('/user','AdminController@user')->name('admin.user');
    Route::get('/property','AdminController@property')->name('admin.property');
    Route::get('/login','AdminController@adminLogin')->name('admin.login');
    Route::any('/check','AdminController@adminCheck')->name('admin.check')->middleware('cmr');
});
