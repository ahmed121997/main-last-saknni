@extends('admin.layouts.app')
@section('links')
    <!-- Custom styles for this page -->
    <link href="{{asset('vendor/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet">
@endsection

@section('content')
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Properties Data</h1>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Properties</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped" id="dataTable_property" >
                        <thead>
                        <tr class="text-center">
                            <td>#</td>
                            <th>Title</th>
                            <th>Type</th>
                            <th>Area</th>
                            <th>Price</th>
                            <th># Rooms</th>
                            <th>Status</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr class="text-center">
                            <td>#</td>
                            <th>Title</th>
                            <th>Type</th>
                            <th>Area</th>
                            <th>Price</th>
                            <th># Rooms</th>
                            <th>Status</th>
                        </tr>
                        </tfoot>
                        <tbody>
                        @if(isset($properties) && count($properties) > 0)
                            @foreach($properties as $property)
                                <tr>
                                    <td>{{$property->id}}</td>
                                    <td>{{$property->des->title}}</td>
                                    <td>{{$property->typeProperty->type_en}}</td>
                                    <td>{{$property->area}}</td>
                                    <td>{{$property->price}}</td>
                                    <td>{{$property->num_rooms}}</td>
                                    <td>{{$property->status}}</td>
                                </tr>
                            @endforeach
                        @endif
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-center">{{$properties->links()}}</div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->
@endsection

@section('script')
    <!-- Page level plugins -->
    <script src="{{asset('public/vendor/datatables/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('public/vendor/datatables/dataTables.bootstrap4.min.js')}}"></script>

    <!-- Page level custom scripts -->
    <script src="{{asset('public/js/admin/demo/datatables-demo.js')}}"></script>
    <script>
        $(document).ready(function() {
            $('#dataTable_property').DataTable();
        });
    </script>
@endsection
