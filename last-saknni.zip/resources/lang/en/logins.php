<?php
return [
    'login'=> 'Login',
    'email' => 'E-Mail Address',
    'password'=> 'Password',
    'remember_me'=> 'Remember Me',
    'forget_your_password' => 'Forget your password?'
];
