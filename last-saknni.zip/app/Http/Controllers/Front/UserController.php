<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Model\Property;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Symfony\Component\Console\Input\Input;

class UserController extends Controller
{
    //

    public function index(){
        $id= Auth::user()->id;
        $properties = Property::with(['des','typeProperty','view','finish','payment'])->where('user_id',$id)->get();
        $not_active = 0;

        foreach ($properties as $property){
            $not_active = $property->status == 0 ? ++$not_active: $not_active;
            $property->status = $property->status ==  1 ? 'Active' : 'Not active';
            $property->images->source = unserialize($property->images->source);
            $property->favorite = $property->isFavorited();
        }

        return view('user.user',compact(['properties','not_active']));
    }

    public function edit(){
        $user = Auth::user();
        return view('user.edit',compact('user'));
    }

    public function favorite(){
        $user = Auth::user();
        $properties = $user->favorite(Property::class);
        foreach($properties as $property){

            $property->images->source = unserialize($property->images->source);
            $property->favorite = $property->isFavorited();
          
        }
    //   return $properties;
    return view('user.favorite', compact('properties'));
    }

    public function update(Request $request,$id){
        $res = User::findorfail($id);
        if($res->email == $request->email){
            $validator  = Validator::make($request->all(), [
                'name' => ['required', 'string', 'max:255'],
                'email' => ['required', 'string', 'email', 'max:255'],
                'phone' => 'digits_between:11,20',
            ]);
        }else{
            $validator  = Validator::make($request->all(), [
                'name' => ['required', 'string', 'max:255'],
                'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
                'phone' => 'digits_between:11,20'
            ]);
        }
        if($validator->passes()) {
            $res->update($request->all());
            return redirect()->route('user.index')->with('success_update','data is updated successfully');
        }
        return redirect()->back()->withErrors($validator)->withInput($request->all());
    }
}
