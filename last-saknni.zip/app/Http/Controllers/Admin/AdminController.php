<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Model\Admin;
use App\Model\Property;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Auth;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin')->except(['adminLogin','adminCheck']);
    }
    public function username(){
        return 'email';
    }


    public function dashboard(){
        $user_count = User::count();
        $property_count = Property::count();
        $not_active = Property::where('status',0)->get()->count();
        // Data Chart
        $max_month = 6;
        $start = Carbon::now()->startOfMonth()->subMonth($max_month - 1);
        $end = Carbon::now()->startOfMonth()->subMonth($max_month - 2);
        $months = [];
        $users = [];
        $properties = [];
        for($i=0;$i<6;$i++){
            $m = $start->format('F');
            $user = User::whereBetween('created_at', [$start, $end])->get();
            $property = Property::whereBetween('created_at', [$start, $end])->get();
            $months[]= $m;
            $users[$m]=count($user);
            $properties[$m]=count($property);
            $start->addMonthsNoOverflow(1);
            $end->addMonthsNoOverflow(1);
        }
        return view('admin.dashboard',compact(['user_count','property_count','not_active','months','users','properties']));
    }
    public function user(){
        $users = User::select()->paginate(PAGING_COUNT);
        foreach ($users as $user){
            $user->status = $user->email_verified_at !=  '' ? 'Verified' : 'Not verified';
        }
        return view('admin.user',compact(['users']));
    }
    public function property(){
        $properties = Property::with(['des','typeProperty','view','finish','payment'])->paginate(PAGING_COUNT);
        $not_active = 0;
        foreach ($properties as $property){
            $not_active = $property->status == 0 ? ++$not_active: $not_active;
            $property->status = $property->status ==  1 ? 'active' : 'not active';
            $property->images->source = unserialize($property->images->source);
        }
        return view('admin.property',compact(['properties','not_active']));
    }

    public function adminLogin(){
        return view('admin.login');
    }
    public function adminCheck(Request $request){
        $this->validate($request, [
            'email'   => 'required|email',
            'password' => 'required',
        ]);
        if (Auth::guard('admin')->attempt(['email' => $request->email, 'password' => $request->password])) {
            return redirect()->intended('/admin');
        }

        return back()->withInput($request->only('email', 'remember'))->withErrors([
            'password' => __('auth.password'),
            ]);

    }

}
