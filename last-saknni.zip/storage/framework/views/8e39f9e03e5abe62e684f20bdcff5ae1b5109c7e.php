<?php $__env->startSection('links'); ?>
    <!-- Custom styles for this page -->
    <link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Properties Data</h1>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Properties</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped" id="dataTable_property" >
                        <thead>
                        <tr class="text-center">
                            <td>#</td>
                            <th>Title</th>
                            <th>Type</th>
                            <th>Area</th>
                            <th>Price</th>
                            <th># Rooms</th>
                            <th>Status</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr class="text-center">
                            <td>#</td>
                            <th>Title</th>
                            <th>Type</th>
                            <th>Area</th>
                            <th>Price</th>
                            <th># Rooms</th>
                            <th>Status</th>
                        </tr>
                        </tfoot>
                        <tbody>
                        <?php if(isset($properties) && count($properties) > 0): ?>
                            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($property->id); ?></td>
                                    <td><?php echo e($property->des->title); ?></td>
                                    <td><?php echo e($property->typeProperty->type_en); ?></td>
                                    <td><?php echo e($property->area); ?></td>
                                    <td><?php echo e($property->price); ?></td>
                                    <td><?php echo e($property->num_rooms); ?></td>
                                    <td><?php echo e($property->status); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-center"><?php echo e($properties->links()); ?></div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('public/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('public/js/admin/demo/datatables-demo.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#dataTable_property').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\last-saknni\resources\views/admin/property.blade.php ENDPATH**/ ?>