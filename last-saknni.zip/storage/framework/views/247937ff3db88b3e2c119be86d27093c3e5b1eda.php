
<?php $__env->startSection('links'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/css/search.css')); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid search">
        <div class="row">
            <div class="col-sm-6 col-md-4 col-lg-3 control">
                <h3><?php echo e(__('property.search_control')); ?></h3>
                <hr/>
                <form id="search-form">
                    <?php echo csrf_field(); ?>
                    <label><?php echo e(__('property.gov')); ?>:</label>
                    <select id="gov" class="custom-select input-search" name="gov">
                        <option value="" selected>Open this select menu</option>
                        <?php if(isset($govs) && count($govs) > 0): ?>
                            <?php $__currentLoopData = $govs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($gov->id); ?>"><?php echo e($gov->governorate_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                    <hr/>
                    <label class="city-label none"><?php echo e(__('property.city')); ?>:</label>
                    <select id="city" class="custom-select input-search none" name="city">
                        <option value="" selected>Open this select menu</option>
                        <optgroup label="cities">

                        </optgroup>
                    </select>
                    <hr class="none"/>
                    <label><?php echo e(__('property.type_property')); ?>:</label>
                    <select id="type_property" class="custom-select input-search" name="type_property">
                        <option value="" selected>Open this select menu</option>
                        <?php if(isset($type_properties) && count($type_properties) > 0): ?>
                            <?php $__currentLoopData = $type_properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type_property->id); ?>"><?php echo e($type_property->type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                    <hr/>

                    <label><?php echo e(__('property.finish')); ?>:</label>
                    <select class="custom-select input-search" name="type_finish">
                        <option value="" selected>Open this select menu</option>
                        <?php if(isset($type_finishes) && count($type_finishes) > 0): ?>
                            <?php $__currentLoopData = $type_finishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_finish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type_finish->id); ?>"><?php echo e($type_finish->type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                    <hr/>
                    <label><?php echo e(__('property.type_pay')); ?>:</label>
                    <select class="custom-select input-search" name="type_payment">
                        <option value="" selected>Open this select menu</option>
                        <?php if(isset($type_payments) && count($type_payments) > 0): ?>
                            <?php $__currentLoopData = $type_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type_payment->id); ?>"><?php echo e($type_payment->type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                    <hr/>
                    <div class="text-center"><button id="search" class="btn btn-secondary mb-2"><?php echo e(__('property.search')); ?></button></div>
                </form>
            </div>
            <div class="col-sm-6 col-md-8 col-lg-9  results">
                <h3 class="h3 mb-0 text-gray-800"><?php echo e(__('property.results')); ?></h3>
                <hr/>
                <div class="row">
                    <div class="lds-ripple"><div></div><div></div></div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>

    <script>
        $("#search").click(function(e){
            e.preventDefault();
            let data = new FormData($('#search-form')[0]);
            $.ajax({
                type: 'post',
                url: '<?php echo e(route("process.search")); ?>',
                data: data,
                processData:false,
                contentType:false,
                beforeSend: function() {
                    $(".lds-ripple").show();
                },
                success: function(data) {
                    if(data.length > 0){
                        let wrapper,wrapper_card,img,card_body,all ="";
                        let url ="<?php echo e(url('public/images/')); ?>";
                        let type = '<?php echo e(__("property.type_property")); ?>';
                        let rooms = '<?php echo e(__("property.number_of_rooms")); ?>';
                        let price = '<?php echo e(__("property.price")); ?>';
                        let area = '<?php echo e(__("property.area")); ?>';
                        let current_url = "<?php echo e(url('property/show/')); ?>";
                        $.each(data,function (key,value) {
                            wrapper = "<div class=' col-lg-6 mb-3 col-xl-4'>";
                            wrapper_card = "<div class='card' style='max-width: 30rem;max-height: 30em'>";
                            img = "<img style='height: 12em' src="+ url +"/"+value.images.source[0]+" class='card-img-top img-thumbnail' alt='img'>";
                            card_body = "<div class='card-body'><h4 class='card-title'>"+value.des.title+
                                "</h4><div class='row'><p class='card-text col-6'><span>"+type +": </span>"+ value.type_property.type +
                                "</p><p class='card-text col-6'><span>"+rooms+" : </span>"+ value.num_rooms +
                                "</p><p class='card-text col-6'><span>"+price+" : </span>"+ value.price +
                                "</p><p class='card-text col-6'><span>"+area+" : </span>"+ value.area +
                                "</p> </div><a target='_blank' href='"+current_url+"/"+value.id+"' class='btn btn-primary'>Show details</a></div></div></div>";
                            all += wrapper + wrapper_card + img + card_body;
                        });
                        $('.results .row').html(all);
                        $(".lds-ripple").hide();
                    }else{
                        $('.results .row').html('<h3 class="m-auto mt-lg-5 text-gray-600 alert alert-danger">There no data</h3>');
                        $(".lds-ripple").hide();
                    }

                    },
                error: function(reject) {

                },
            });
        });
    </script>
    <script>
        $("#gov").change(function(){
            $.ajax({
                type: 'post',
                url: '<?php echo e(route("get.cities")); ?>',
                data: {
                    '_token' : '<?php echo e(csrf_token()); ?>',
                    'id' : this.value,
                },
                success: function(data) {
                    let all_opt = "";
                    $.each(data,function (key,value) {
                        all_opt += " <option value=" + value.id+ ">" + value.city_name + "</option> ";
                    });
                    $('.none').show();
                    $("#city > optgroup").html(all_opt);
                },
                error: function(reject) {

                },
            });
        });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\last-saknni\resources\views/search/search.blade.php ENDPATH**/ ?>