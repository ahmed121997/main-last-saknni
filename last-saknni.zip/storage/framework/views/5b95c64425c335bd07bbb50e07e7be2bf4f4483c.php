<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="display-comment">
        <strong><?php echo e($comment->user->name); ?></strong>
        <p><?php echo e($comment->body); ?></p>
        
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\last-saknni\resources\views/property/commentsDisplay.blade.php ENDPATH**/ ?>