
<?php
$src = $properties->images->source;
?>
<?php $__env->startSection('links'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/showProperty.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="h2"><?php echo e($properties->des->title); ?></h2>
        <div class="mb-2 properties-icon">
            <span ><i class="fas fa-map-marker-alt"></i> <?php echo e($properties->city->city_name); ?></span>
            <span><i class="fas fa-building"></i> <?php echo e($properties->typeProperty->type); ?></span>
            <span><i class="fas fa-expand"></i> <bdi><?php echo e($properties->area); ?> <?php echo e(__('property.m')); ?> <sup>2</sup></bdi></span>
            <span style="float: <?php echo e(app()->getLocale() == 'en'?'right ;margin-right: 5em;':'left;margin-left:5em'); ?> ;font-weight: bold;font-size: large;color:#F89406"><?php echo e($properties->price); ?> <?php echo e(__('property.eg')); ?> <?php if($properties->list_section == 'rent'): ?> / <?php echo e($properties->type_rent); ?> <?php endif; ?></span>
        </div>
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <?php if(isset($src) && count($src) > 0): ?>
                    <?php for($i=0;$i<count($src);$i++): ?>
                        <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>" class="<?php if($i === 0): ?> active <?php endif; ?>"></li>
                    <?php endfor; ?>
                <?php endif; ?>
            </ol>
            <div class="carousel-inner" style="height: 30em;position: relative;">
                <?php if(isset($src) && count($src) > 0): ?>
                    <?php for($i=0;$i<count($src);$i++): ?>
                        <div class="carousel-item <?php if($i === 0): ?> active <?php endif; ?> position-relative">
                            <img class="d-block w-100 img-thumbnail" style="height: 30em;" src="<?php echo e(url('public/images/' .$properties->images->source[$i])); ?>" alt="First slide">
                        </div>
                    <?php endfor; ?>
                <?php endif; ?>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
        <div class="container show-property">
            <div class="row">
                <?php if(isset($properties)): ?>
                    <div id="<?php echo e($properties->id); ?>" class="col-sm-12 col-md-8 mt-3 alert alert-info">
                        <div class="row">
                            <div class="col-12"><h4><?php echo e(__('property.information_about_Property')); ?> :</h4></div>
                            <div class="col-xs-12 col-sm-6 col-md-4 "><span><?php echo e(__('property.type_property')); ?> :  </span> <?php echo e($properties->typeProperty->type); ?></div>
                            <div class="col-xs-12 col-sm-6 col-md-4 " ><span><?php echo e(__('property.view')); ?> :  </span> <?php echo e($properties->view->list); ?></div>
                            <div class="col-xs-12 col-sm-6 col-md-4 "><span><?php echo e(__('property.use_for')); ?> :  </span> <?php echo e($properties->list_section); ?></div>
                            <div class="col-xs-12 col-sm-6 col-md-4 "><span><?php echo e(__('property.floor')); ?> :  </span> <?php echo e($properties->num_floor); ?></div>
                            <div class="col-xs-12 col-sm-6 col-md-4 "><span><?php echo e(__('property.number_of_rooms')); ?> :  </span> <?php echo e($properties->num_rooms); ?></div>
                            <div class="col-xs-12 col-sm-6 col-md-4 "><span><?php echo e(__('property.number_of_bathrooms')); ?>:  </span> <?php echo e($properties->num_bathroom); ?></div>
                            <div class="col-xs-12 col-sm-6 col-md-4 "><span><?php echo e(__('property.finish')); ?> :  </span> <?php echo e($properties->finish->type); ?></div>
                            <div class="col-xs-12 col-sm-6 col-md-4 "><span><?php echo e(__('property.city')); ?> :  </span> <?php echo e($properties->city->city_name); ?></div>
                            <div class="col-xs-12 col-sm-6 col-md-4 "><span><?php echo e(__('property.type_pay')); ?> :  </span> <?php echo e($properties->payment->type); ?></div>
                            <div class="col-xs-12 col-sm-6 col-md-4" style="color:#F89406"><span><?php echo e(__('property.price')); ?> :  </span > <?php echo e($properties->price); ?> <?php echo e(__('property.eg')); ?><?php if($properties->list_section == 'rent'): ?> / <?php echo e($properties->type_rent); ?> <?php endif; ?> </div>
                            <div class="col-xs-12 col-sm-6 col-md-4 "><span><?php echo e(__('property.link_youtube')); ?> :  </span><button class="btn btn-primary"><a href="<?php echo e($properties->link_youtube); ?>" target="_blank">Youtube link</a></button> </div>
                            <div class="col-xs-12 col-sm-6 col-md-4 "><span><?php echo e(__('property.location')); ?> :  </span> <?php echo e($properties->location); ?></div>
                            <div class="col-12"><hr/></div>
                            <div class="col-12 "><span class="text-dark font-weight-bold"><?php echo e(__('property.details_property')); ?> :  </span>
                                <p class="text-secondary ">
                                    <?php echo e($properties->des->details); ?>

                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="co-sm-12 col-md-4 text-center contact mt-md-5">
                        <div >
                            <div class="mt-5 mb-3">
                                <button class="btn btn-primary w-75  show-number btn-lg"><i class="fas fa-phone"></i><?php echo e(__('property.show_number')); ?></button>
                                <a class="btn btn-primary btn-lg number-phone mb-3 " href="tel:<?php echo e($properties->user->phone); ?>"><?php echo e($properties->user->phone); ?></a>
                            </div>
                            <div class="mt-3">
                                <button class="btn btn-primary w-75 show-email btn-lg"><i class="fas fa-envelope-square"></i><?php echo e(__('property.show_email')); ?></button>
                                <div class="mt-4"></div>
                                <a class="btn btn-primary email btn-lg mt-3 " href="mailto:<?php echo e($properties->user->email); ?>"><?php echo e($properties->user->email); ?></a>
                            </div>

                        </div>
                    </div>

                <?php endif; ?>
            </div>
        </div>
        <div class="container mt-3" id="display_comment">
            <h3><?php echo e(__('property.comments')); ?></h3>
            <?php echo $__env->make('property.commentsDisplay', ['comments' => $properties->comments, 'property_id' => $properties->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="container">
            <hr />
            <?php if(auth()->guard()->check()): ?>
            <h4><?php echo e(__('property.add_comment')); ?></h4>
            <form class="add-comment">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <textarea  class="form-control" name="body" id="comment_body"></textarea>
                    <input type="hidden" name="property_id" value="<?php echo e($properties->id); ?>" />
                    <p class="text-danger error"></p>
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-success btn-add-comment" value="<?php echo e(__('property.add_comment')); ?>" />
                </div>
            </form>
              <?php else: ?>
                <div class="text-primary text-center"> <?php echo e(__('property.to_add_comment')); ?> <a class="btn btn-sm btn-primary" href="<?php echo e(route('login')); ?>"><?php echo e(__('property.login')); ?></a></div>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('public/js/showProperty.js')); ?>"></script>
    
    <?php if(auth()->guard()->check()): ?>
    <script>
        $(".btn-add-comment").click(function(e){
            let property_id = $('.add-comment input[name="property_id"]')[0].value;
            let body = $('.add-comment #comment_body')[0].value;
            e.preventDefault();
            if(body  != ""){
                $('.error').show().text("");
                $.ajax({
                    type: 'post',
                    url: '<?php echo e(route("comments.store")); ?>',
                    data: {
                        '_token' : "<?php echo e(csrf_token()); ?>",
                        'property_id' : property_id,
                        'body' :  body,
                    },
                    success: function(data) {
                        if(data.status == true){
                            $('#display_comment ').append(
                                '<div class="display-comment">'+

                                '        <strong><?php echo e(Auth::user()->name); ?></strong>\n' +
                                '        <p>'+ body +'</p>\n' +
                                '        </div>'
                                );
                            $('#comment_body')[0].value = "";
                        }
                    },
                    error: function(reject) {

                    },
                });
            }else{
                $('.error').show().text('comment body is required');
            }

        });
        </script>
    <?php endif; ?>
        

    <?php echo $__env->make('layouts.scriptFavorite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\last-saknni\resources\views/property/show.blade.php ENDPATH**/ ?>