// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#dataTable_user').DataTable();
  $('#dataTable_property').DataTable();
});
