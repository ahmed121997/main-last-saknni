<?php
    // title page
    $title = 'dashboard';

    $users_count = isset($user_count)? $user_count:'undefined';
    $properties_count = isset($property_count)? $property_count:'undefined';
    $percentage_not_active = isset($not_active)? ($not_active/$properties_count) *100:0;
    $percentage_active = 100 - $percentage_not_active;
?>

    <?php $__env->startSection('links'); ?>
    <link href="<?php echo e(asset('public/css/admin/all.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/css/user.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
        <div class="container">
            <?php if(Session::has('success_update')): ?>
                <div class="message text-success"><i class="fa fa-check-circle" aria-hidden="true"></i> <?php echo e(Session::get('success_update')); ?></div>

            <?php endif; ?>
                <?php if(Session::has('message')): ?>
                    <div class="message text-success"><i class="fa fa-check-circle" aria-hidden="true"></i> <?php echo e(Session::get('message')); ?></div>

                <?php endif; ?>
            <div id="accordion">
                <div class="card">
                    <div class="card-header" id="headingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                <?php echo e(__('users.personal_information')); ?>

                            </button>
                        </h5>
                    </div>

                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                        <div class="card-body">
                            <div><span><?php echo e(__('users.name')); ?> : </span> <?php echo e(Auth::guard('admin')->user()->name); ?></div>
                            <div><span><?php echo e(__('users.email')); ?> : </span> <?php echo e(Auth::guard('admin')->user()->email); ?></div>
                            <div><span><?php echo e(__('users.phone')); ?> : </span> <?php echo e(Auth::guard('admin')->user()->phone); ?></div>
                            <div><span><?php echo e(__('users.last_edit')); ?> : </span> <?php echo e(Auth::guard('admin')->user()->updated_at); ?></div>
                
                            <button class="btn btn-primary  d-block ml-auto mt-3"><a href="<?php echo e(route('admin.profile.edit')); ?>">Edit</a></button>
                        </div>
                    </div>
                </div>
            </div>
            <!-------- end accordion--------------->
            

        </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('public/js/admin/all.js')); ?>"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.bundle.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"></script>
        <!-- include script chart users-->
        
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\last-saknni-main\resources\views/admin/profile/admin.blade.php ENDPATH**/ ?>