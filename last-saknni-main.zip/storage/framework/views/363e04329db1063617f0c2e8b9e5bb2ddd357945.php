<?php $__env->startSection('links'); ?>

    <link href="<?php echo e(asset('public/css/addProperty.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- MultiStep Form -->
    <div class="container justify-content-center">
        <!-- MultiStep Form -->
        <div class="row">
            <?php if(app()->getLocale() == 'ar'): ?>
                <div class="col-md-1 col-lg-2"></div>
            <?php endif; ?>
            <div class="col-sm-12 col-md-10 col-lg-8 offset-md-1 offset-lg-2">
                <form id="msform" method="post" action="<?php echo e(route('update.property')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <!-- progressbar -->
                    <ul id="progressbar">
                        <li class="active"><?php echo e(__('property.get_started')); ?></li>
                        <li><?php echo e(__('property.details_for_property')); ?></li>
                        <li><?php echo e(__('property.your_location')); ?></li>
                        <li><?php echo e(__('property.title')); ?> </li>
                        <li><?php echo e(__('property.property_price')); ?></li>
                        <li><?php echo e(__('property.description')); ?></li>
                    </ul>
                    <!-- start fieldset one -->
                    <input type="text" name="id" hidden value="<?php echo e($properties->id); ?>"/>
                    <input type="text" name="id_des" hidden value="<?php echo e($properties->des->id); ?>"/>
                    <fieldset>
                        <h2 class="fs-title"><?php echo e(__('property.get_started_update_your_property')); ?></h2>
                        <h3 class="fs-subtitle"><?php echo e(__('property.build_info_about_your_property')); ?></h3>

                        <label><?php echo e(__('property.type_property')); ?>:</label>
                        <select name="typeProperty" id="typeProperty">
                            <option value="" disabled><?php echo e(__('property.choose_type_property')); ?></option>
                            <?php if(isset($type_properties) && count($type_properties) > 0): ?>
                                <?php $__currentLoopData = $type_properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        <?php if($properties->type_property_id === $type_property->id): ?> selected class="text-success"
                                        <?php endif; ?> value="<?php echo e($type_property->id); ?>"><?php echo e($type_property->type); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>

                        <label><?php echo e(__('property.list_section')); ?>:</label>
                        <select name="listSection" id="listSection">
                            <option value="" disabled><?php echo e(__('property.choose_list_section')); ?></option>
                            <option <?php if($properties->list_section === 'sell'): ?> selected class="text-success"
                                    <?php endif; ?> value="sell"><?php echo e(__('property.sell')); ?></option>
                            <option <?php if($properties->list_section === 'rent'): ?> selected class="text-success"
                                    <?php endif; ?> value="rent"><?php echo e(__('property.rent')); ?></option>
                        </select>
                        <?php if($properties->list_section == 'rent'): ?>
                        <label class="type-rent"><?php echo e(__('property.type_rent')); ?>:</label>
                        <select name="type_rent" class="type-rent">
                            <option <?php if($properties->type_rent === 'daily'): ?> selected class="text-success"
                                    <?php endif; ?> value="daily"><?php echo e(__('property.daily')); ?></option>
                            <option <?php if($properties->type_rent === 'monthly'): ?> selected class="text-success"
                                    <?php endif; ?> value="monthly"><?php echo e(__('property.monthly')); ?></option>
                        </select>
                        <?php endif; ?>
                        <label><?php echo e(__('property.area')); ?>:</label>
                        <input type="text" name="area" id="area" placeholder="<?php echo e(__('property.area')); ?> - 40-5000" value="<?php echo e($properties->area); ?>"  autoComplete="off"/>

                        <label><?php echo e(__('property.view_list')); ?>:</label>
                        <select name="listView" id="listView">
                            <option value="" disabled><?php echo e(__('property.choose_listing_view')); ?></option>

                            <?php if(isset($list_views) && count($list_views) > 0): ?>
                                <?php $__currentLoopData = $list_views; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list_view): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($properties->list_view_id === $list_view->id): ?> selected class="text-success"
                                        <?php endif; ?> value="<?php echo e($list_view->id); ?>"><?php echo e($list_view->list); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <input  type="button" name="next" class="next action-button btn" value="<?php echo e(__('property.next')); ?>"/>
                    </fieldset>
                    <!-- end fieldset one -->
                    <!-- Start fieldset two -->
                    <fieldset>
                        <h2 class="fs-title"><?php echo e(__('property.details_for_Property')); ?></h2>
                        <h3 class="fs-subtitle"><?php echo e(__('property.tell_us_details_about_your_property')); ?></h3>

                        <label><?php echo e(__('property.floor')); ?>:</label>
                        <input   type="text" name="floor" id="floor" placeholder="<?php echo e(__('property.floor')); ?> 0 - 100" autoComplete="off" value="<?php echo e($properties->num_floor); ?>"/>

                        <label><?php echo e(__('property.rooms')); ?>:</label>
                        <input   type="text" name="rooms" id="rooms" placeholder="<?php echo e(__('property.number_of_rooms')); ?> 1 - 100" autoComplete="off" value="<?php echo e($properties->num_rooms); ?>"/>

                        <label><?php echo e(__('property.bathrooms')); ?>:</label>
                        <input   type="text" name="bathroom" id="bathroom" placeholder="<?php echo e(__('property.number_of_bathrooms')); ?> 1 - 50" autoComplete="off" value="<?php echo e($properties->num_bathroom); ?>"/>

                        <label><?php echo e(__('property.type_finish')); ?>:</label>
                        <select name="typeFinish" id="typeFinish">
                            <option value="" disabled><?php echo e(__('property.choose_type_of_finish')); ?></option>
                            <?php if(isset($type_finishes) && count($type_finishes) > 0): ?>
                                <?php $__currentLoopData = $type_finishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_finish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($properties->type_finish_id === $type_finish->id): ?> selected class="text-success"
                                            <?php endif; ?> value="<?php echo e($type_finish->id); ?>"><?php echo e($type_finish->type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>

                        <input type="button" name="previous" class="previous action-button-previous" value="<?php echo e(__('property.previous')); ?>"/>
                        <input type="button" name="next" class="next action-button" value="<?php echo e(__('property.next')); ?>"/>
                    </fieldset>
                    <!-- End fieldset two -->

                    <!-- Start fieldset three -->
                    <fieldset>
                        <h2 class="fs-title"><?php echo e(__('property.your_location')); ?></h2>
                        <h3 class="fs-subtitle"><?php echo e(('property.tell_us_about_location_of_property')); ?></h3>
                        <!--choose your governorate for your property -->
                        <label><?php echo e(__('property.gov')); ?>:</label>
                        <select name="gov" id="gov">
                            <option value="" disabled><?php echo e(__('property.choose_governorate')); ?></option>
                            <?php if(isset($govs) && count($govs) > 0): ?>
                                <?php $__currentLoopData = $govs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($properties->city->gov_id === $gov->id): ?> selected class="text-success"
                                            <?php endif; ?> value="<?php echo e($gov->id); ?>"><?php echo e($gov->governorate_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>

                        <label><?php echo e(__('property.city')); ?>:</label>
                        <select name="city" id="city">
                            <option  value="" disabled><?php echo e(__('property.choose_city')); ?></option>
                            <optgroup label="all cities in this gov">
                                <?php if(isset($cities) && count($cities) > 0): ?>
                                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($properties->city->id === $city->id): ?> selected class="text-success"
                                                <?php endif; ?> value="<?php echo e($city->id); ?>"><?php echo e($city->city_name_en); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </optgroup>
                        </select>

                        <label><?php echo e(__('property.location')); ?>:</label>
                        <input type="text" name="location" id="location" placeholder="<?php echo e(__('property.location_by_details')); ?>" autoComplete="off" value="<?php echo e($properties->location); ?>"/>

                        <input type="button" name="previous" class="previous action-button-previous" value="<?php echo e(__('property.previous')); ?>"/>
                        <input type="button" name="next" class="next action-button" value="<?php echo e(__('property.next')); ?>"/>
                    </fieldset>
                    <!-- End fieldset three -->

                    <!-- Start fieldset four -->
                    <fieldset>
                        <h2 class="fs-title"><?php echo e(__('property.title_your_ads.')); ?></h2>
                        <h3 class="fs-subtitle"><?php echo e(__('property.tell_us_what_Title_you_want_to_be_show')); ?></h3>

                        <label><?php echo e(__('property.title')); ?>:</label>
                        <input type="text" name="title" id="title" placeholder="<?php echo e(__('property.title')); ?>" value="<?php echo e($properties->des->title); ?>"/>

                        <label><?php echo e(__('property.details')); ?>:</label>
                        <textarea name="details" id="details" placeholder="<?php echo e(__('property.details')); ?>"><?php echo e($properties->des->details); ?></textarea>

                        <input type="button" name="previous" class="previous action-button-previous" value="<?php echo e(__('property.previous')); ?>"/>
                        <input type="button" name="next" class="next action-button" value="<?php echo e(__('property.next')); ?>"/>
                    </fieldset>
                    <!-- End fieldset four -->

                    <!-- Start fieldset five -->
                    <fieldset>
                        <h2 class="fs-title"><?php echo e(__('property.property_price')); ?></h2>
                        <h3 class="fs-subtitle"><?php echo e(__('property.tell_us_about_your_price_you_want')); ?></h3>

                        <label><?php echo e(__('property.type_pay')); ?>:</label>
                        <select name="typePay" id="typePay">
                            <option value="" disabled><?php echo e(__('property.choose_type_pay')); ?></option>
                            <?php if(isset($type_payments) && count($type_payments) > 0): ?>
                                <?php $__currentLoopData = $type_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($properties->type_payment_id === $type_payment->id): ?> selected class="text-success"
                                            <?php endif; ?> value="<?php echo e($type_payment->id); ?>"><?php echo e($type_payment->type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>

                        <label><?php echo e(__('property.price')); ?>:</label>
                        <input type="text" name="price" id="price" placeholder="<?php echo e(__('property.price')); ?>" autocapitalize="off" value="<?php echo e($properties->price); ?>"/>
                        <label><?php echo e(__('property.phone')); ?>:</label>
                        <input type="text"  name="phone" id="phone" placeholder="Phone" autocomplete="off" value="<?php echo e(Auth::user()->phone); ?>"/>

                        <input type="button" name="previous" class="previous action-button-previous" value="<?php echo e(__('property.previous')); ?>"/>
                        <input type="button" name="next" class="next action-button" value="Next"/>
                    </fieldset>
                    <!-- End fieldset five -->

                    <!-- Start fieldset six -->
                    <fieldset>
                        <h2 class="fs-title"><?php echo e(__('property.description')); ?></h2>
                        <h3 class="fs-subtitle"><?php echo e(__('property.describe_your_property_by_images_or_youtube')); ?></h3>

                        <label><?php echo e(__('property.link_youtube')); ?>:</label>
                        <input type="text" name="linkYoutube" id="linkYoutube" placeholder="<?php echo e(__('property.link_youtube')); ?>" value="<?php echo e($properties->link_youtube); ?>"/>


                        <input type="button" name="previous" class="previous action-button-previous" value="<?php echo e(__('property.previous')); ?>"/>
                        <input type="submit" name="submit" class="submit action-button" value="<?php echo e(__('property.submit')); ?>"/>
                    </fieldset>
                    <!-- End fieldset six -->

                    <div style="margin: 10px auto;width:80%" class="alert alert-danger error"></div>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger mt-3">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p><?php echo e($error); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                </form>

            </div>
        </div>
        <!-- /.MultiStep Form -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script  src="<?php echo e(asset('public/js/addProperty.js')); ?>"></script>
    <script>
        $("#gov").change(function(){
            $.ajax({
                type: 'post',
                url: '<?php echo e(route("get.cities")); ?>',
                data: {
                    '_token' : '<?php echo e(csrf_token()); ?>',
                    'id' : this.value,
                },
                success: function(data) {
                    let all_opt = "";
                    $.each(data,function (key,value) {
                        all_opt += " <option value=" + value.id+ ">" + value.city_name + "</option> ";
                    });
                    $("#city > optgroup").html(all_opt);
                },
                error: function(reject) {

                },
            });
        });



        $("#listSection").click(function () {
            let type_rent = '<?php echo e(__("property.type_rent")); ?>';
            let daily = '<?php echo e(__("property.daily")); ?>';
            let monthly = '<?php echo e(__("property.monthly")); ?>';
            if($(this).val() === 'rent') {
                if(!$(".type-rent")[0]){
                    $(this).after('<label class="type-rent">'+type_rent+':</label>' +
                        '<select name="type_rent" class="type-rent""">' +
                        '<option value="daily">'+daily+'</option>' +
                        '<option value="monthly">'+monthly+'</option>' +
                        '</select>');
                }
            }else{
                $(".type-rent").remove();
            }
        });



    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\last-saknni-main\resources\views/property/edit.blade.php ENDPATH**/ ?>