<?php $__env->startSection('links'); ?>

<link href="<?php echo e(asset('public/css/welcome.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container welcome">
    <h3 class="mt-lg-3"> <i class="fa fa-home" aria-hidden="true"></i> <?php echo e(__('property.favorite_properties')); ?></h3>
    <hr/>
    <div class="row">
        <?php if(isset($properties) && count($properties) > 0): ?>
            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card " style="max-width: 30rem;max-height: 30em;min-height: 30em">
                        <img style="height: 14em" src="<?php echo e(url('public/images/'. $property->images->source[0])); ?>" class="card-img-top img-thumbnail" alt="img">
                        <div class="ml-2 mt-2 properties-icon">
                            <span ><i class="fas fa-map-marker-alt"></i><?php if(app()->getLocale() == 'en'): ?> <?php echo e($property->city->city_name_en); ?> <?php else: ?> <?php echo e($property->city->city_name_ar); ?> <?php endif; ?></span>
                            <span><i class="fas fa-building"></i> <?php echo e($property->typeProperty->type_en); ?></span>
                            <span> <i class="fas fa-expand"></i> <bdi><?php echo e($property->area); ?> <?php echo e(__('property.m')); ?> <sup>2</sup></bdi></span>
                        </div>
                        <div class="card-body">

                            <h4 class="card-title mt-1"><?php echo e($property->des->title); ?></h4>
                            <div class="row" style="height: 110px">
                                <p class="card-text col-6"><span><?php echo e(__('property.finish')); ?> : </span> <?php if(app()->getLocale() == 'en'): ?> <?php echo e($property->finish->type_en); ?> <?php else: ?> <?php echo e($property->finish->type_ar); ?> <?php endif; ?></p>
                                <p class="card-text col-6"><span><?php echo e(__('property.rooms')); ?> : </span><?php echo e($property->num_rooms); ?></p>
                                <p class="card-text col-6"><span><?php echo e(__('property.price')); ?>  : </span><?php echo e($property->price); ?> <?php echo e(__('property.eg')); ?><?php if($property->list_section == 'rent'): ?> / <?php echo e($property->type_rent); ?> <?php endif; ?></p>
                                <p class="card-text col-6"><span><?php echo e(__('property.view')); ?>  : </span> <?php if(app()->getLocale() == 'en'): ?> <?php echo e($property->view->list_en); ?> <?php else: ?> <?php echo e($property->view->list_ar); ?> <?php endif; ?></p>
                            </div>

                            <a href="<?php echo e(route('show.property',$property->id)); ?>" class="btn btn-primary" target="_blank"><?php echo e(__('property.show_details')); ?></a>

                            <?php echo $__env->make('property.favorite',['id'=>$property->id,'fav'=>$property->favorite], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php echo $__env->make('layouts.scriptFavorite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\last-saknni-main\resources\views/user/favorite.blade.php ENDPATH**/ ?>