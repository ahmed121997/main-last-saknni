<?php $__env->startSection('links'); ?>

    <link href="<?php echo e(asset('public/css/showAllProperty.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php if(isset($properties) && count($properties) > 0): ?>
                <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-4  mb-4">
                        <div class="card mb-3" style="max-width: 30rem;max-height: 30em;min-height: 30em">
                            <img style="height: 14em" src="<?php echo e(url('public/images/'. $property->images->source[1])); ?>" class="card-img-top img-thumbnail" alt="img">
                            <div class="ml-2 mt-2 properties-icon">
                                <span ><i class="fas fa-map-marker-alt"></i> <?php echo e($property->city->city_name); ?></span>
                                <span><i class="fas fa-building"></i> <?php echo e($property->typeProperty->type); ?></span>
                                <span><i class="fas fa-expand"></i> <bdi><?php echo e($property->area); ?> <?php echo e(__('property.m')); ?> <sup>2</sup></bdi></span>
                            </div>
                            <div class="card-body">

                                <h5 class="card-title"><?php echo e($property->des->title); ?></h5>
                                <div class="row" style="height: 110px">
                                    <p class="card-text col-6"><span><?php echo e(__('property.finish')); ?> : </span><?php echo e($property->finish->type); ?></p>
                                    <p class="card-text col-6"><span><?php echo e(__('property.rooms')); ?> : </span><?php echo e($property->num_rooms); ?></p>
                                    <p class="card-text col-6"><span><?php echo e(__('property.price')); ?>  : </span><?php echo e($property->price); ?> <?php echo e(__('property.eg')); ?> <?php if($property->list_section == 'rent'): ?> / <?php echo e($property->type_rent); ?> <?php endif; ?></p>
                                    <p class="card-text col-6"><span><?php echo e(__('property.view')); ?>  : </span><?php echo e($property->view->list); ?></p>
                                </div>

                                <a href="<?php echo e(route('show.property',$property->id)); ?>" class="btn btn-primary" target="_blank"><?php echo e(__('property.show_details')); ?></a>
                                <?php echo $__env->make('property.favorite',['id'=>$property->id,'fav'=>$property->favorite], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="d-flex justify-content-center mt-2"><?php echo e($properties->links()); ?></div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

    <?php echo $__env->make('layouts.scriptFavorite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\last-saknni-main\resources\views/property/showAll.blade.php ENDPATH**/ ?>