<?php $__env->startSection('links'); ?>

    <link href="<?php echo e(asset('public/css/user.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(Session::has('success_update')): ?>
            <div class="message text-success"><i class="fa fa-check-circle" aria-hidden="true"></i> <?php echo e(Session::get('success_update')); ?></div>

        <?php endif; ?>
            <?php if(Session::has('message')): ?>
                <div class="message text-success"><i class="fa fa-check-circle" aria-hidden="true"></i> <?php echo e(Session::get('message')); ?></div>

            <?php endif; ?>
        <div id="accordion">
            <div class="card">
                <div class="card-header" id="headingOne">
                    <h5 class="mb-0">
                        <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            <?php echo e(__('users.personal_information')); ?>

                        </button>
                    </h5>
                </div>

                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                    <div class="card-body">
                        <div><span><?php echo e(__('users.name')); ?> : </span> <?php echo e(Auth::user()->name); ?></div>
                        <div><span><?php echo e(__('users.email')); ?> : </span> <?php echo e(Auth::user()->email); ?></div>
                        <div><span><?php echo e(__('users.phone')); ?> : </span> <?php echo e(Auth::user()->phone); ?></div>
                        <div><span><?php echo e(__('users.last_edit')); ?> : </span> <?php echo e(Auth::user()->updated_at); ?></div>
                        <div class="text-danger font-weight-bold"><span><?php echo e(__('users.ads_not_active')); ?> : </span> <?php echo e($not_active); ?></div>
                        <div class="text-right">
                            <button class="btn btn-primary  mr-3 mt-3"><a href="<?php echo e(route('user.edit')); ?>">Edit</a></button>
                            <button class="btn btn-primary mr-3 mt-3"><a href="<?php echo e(route('user.change_password')); ?>">Change Password</a></button>
                        </div>
                       
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header" id="headingTwo">
                    <h5 class="mb-0">
                        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            <?php echo e(__('users.your_properties')); ?>

                        </button>
                    </h5>
                </div>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                    <div class="card-body">
                        <div class="table-wrapper-scroll-y my-custom-scrollbar">
                            <?php if(isset($properties) && count($properties) > 0): ?>
                            <table class="table table-bordered table-striped mb-0">
                                <thead class="thead-dark">
                                <tr class="text-center">
                                    <th scope="col">#</th>
                                    <th scope="col"><?php echo e(__('users.type')); ?></th>
                                    <th scope="col"><?php echo e(__('users.view')); ?></th>
                                    <th scope="col"><?php echo e(__('users.area')); ?></th>
                                    <th scope="col"><?php echo e(__('users.price')); ?></th>
                                    <th scope="col"><?php echo e(__('users.#_rooms')); ?></th>
                                    <th scope="col"><?php echo e(__('users.#_bathrooms')); ?></th>
                                    <th scope="col"><?php echo e(__('users.status')); ?></th>
                                    <th scope="col"><?php echo e(__('users.control')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                        <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text-center">
                                            <th scope="row"><?php echo e($property->id); ?></th>
                                            <td><?php echo e(app()->getLocale() == 'en'?$property->typeProperty->type_en : $property->typeProperty->type_ar); ?></td>
                                            <td><?php echo e(app()->getLocale() == 'en'? $property->view->list_en : $property->view->list_ar); ?></td>
                                            <td><?php echo e($property->area); ?></td>
                                            <td><?php echo e($property->price); ?></td>
                                            <td><?php echo e($property->num_rooms); ?></td>
                                            <td><?php echo e($property->num_bathroom); ?></td>
                                            <td class="<?php if($property->status === 'Not active'): ?> text-danger <?php endif; ?>"><?php echo e($property->status); ?></td>

                                            <td>
                                                <?php if($property->status === 'Not active'): ?>

                                                    <abbr title="<?php echo e(__('users.active')); ?>" ><a target="_blank" href="<?php echo e(route('property.activation',$property->id)); ?>"><i class="fas fa-exclamation-circle text-success"></i></a></abbr>
                                                <?php endif; ?>
                                                    <abbr title="<?php echo e(__('users.show')); ?>"> <a  id="btn-<?php echo e($property->id); ?>" href="#<?php echo e($property->id); ?>" class="button_show"><i class="fas fa-eye text-primary"></i></a></abbr>

                                                    <abbr title="<?php echo e(__('users.edit')); ?>"> <a href="<?php echo e(route('edit.property',$property->id)); ?>" target="_blank"><i class="fas fa-edit text-secondary"></i></a></abbr>

                                                    <abbr title="<?php echo e(__('users.delete')); ?>"><a class="property-delete" href="<?php echo e(route('delete.property',$property->id)); ?>" ><i class="far fa-trash-alt text-danger"></i></a></abbr>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php else: ?>
                            <div class="text-danger text-center"><?php echo e(__('users.no_properties')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-------- end accordion--------------->
        <div class="container show-property">
            <div class="row">

                <?php if(isset($properties) && count($properties) > 0): ?>
                    <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div id="<?php echo e($property->id); ?>" class="col col-12 property property-<?php echo e($property->id); ?>  mt-lg-5 alert alert-info">
                            <h3 class="text-gray-600 "><?php echo e(__('users.property')); ?> # <?php echo e($property->id); ?></h3>
                            <hr class="mb-5"/>
                            <div class="row">
                                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3"><span><?php echo e(__('users.type_property')); ?> :  </span> <?php echo e(app()->getLocale() == 'en'?$property->typeProperty->type_en : $property->typeProperty->type_ar); ?></div>
                                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3" ><span><?php echo e(__('users.view')); ?> :  </span> <?php echo e(app()->getLocale() == 'en'? $property->view->list_en : $property->view->list_ar); ?></div>
                                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3"><span><?php echo e(__('users.usage')); ?> :  </span> <?php echo e($property->list_section); ?></div>
                                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3"><span><?php echo e(__('users.floor')); ?> :  </span> <?php echo e($property->num_floor); ?></div>
                                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3"><span><?php echo e(__('users.number_of_rooms')); ?> :  </span> <?php echo e($property->num_rooms); ?></div>
                                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3"><span><?php echo e(__('users.number_of_bathrooms')); ?> :  </span> <?php echo e($property->num_bathroom); ?></div>
                                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3"><span><?php echo e(__('users.type_finish')); ?> :  </span> <?php echo e(app()->getLocale() == 'en'? $property->finish->type_en:$property->finish->type_ar); ?></div>
                                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3"><span><?php echo e(__('users.city')); ?> :  </span> <?php echo e($property->city->city_name_en); ?></div>
                                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3"><span><?php echo e(__('users.type_pay')); ?> :  </span> <?php echo e($property->payment->type); ?></div>
                                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3"><span><?php echo e(__('users.price')); ?> :  </span> <?php echo e($property->price); ?></div>
                                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3"><span><?php echo e(__('users.link_youtube')); ?> :  </span><a class="link-youtube" href="<?php echo e($property->link_youtube); ?>">Youtube link</a></div>
                                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3"><span><?php echo e(__('users.location')); ?> :  </span> <?php echo e($property->location); ?></div>

                                <div class="col-12"><span><?php echo e(__('users.images')); ?>:  </span>
                                    <?php if(isset($property->images->source) && count($property->images->source)): ?>
                                        <div class="row">
                                            <?php for($i = 0; $i< count($property->images->source);$i++): ?>
                                                <div class="col-sm-12 col-md-6 col-lg-4">
                                                    <img style="width: 20em;height: 20em;" class="img-thumbnail" src="<?php echo e(url('public/images/'. $property->images->source[$i])); ?>" alt=""/>
                                                </div>
                                            <?php endfor; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $('.button_show').click(function (e) {
    let btn_id = this.getAttribute('id');
    let id = btn_id.search("-");
    $('.property-'+btn_id.slice(id+1)).fadeToggle().siblings('.property').hide();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\last-saknni-main\resources\views/user/user.blade.php ENDPATH**/ ?>