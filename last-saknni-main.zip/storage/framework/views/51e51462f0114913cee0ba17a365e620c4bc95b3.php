<?php $__env->startSection('links'); ?>

    <link href="<?php echo e(asset('public/css/activation.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container justify-content-center activation">
    <div class="icons-payment">
        <img src="<?php echo e(asset('public/images/activation/visa.png')); ?>" alt="Visa" />
        <img src="<?php echo e(asset('public/images/activation/mastercard.png')); ?>" alt="Mastercard" />
        <img src="<?php echo e(asset('public/images/activation/american-express.png')); ?>" alt="American-express" />
    </div>
    <button class="btn btn-primary d-block ">
        <a href="#" class="d-flex justify-content-center" id="activation-btn" style="color:#FFF;text-decoration: none;">
            <div>Activation now</div>
            <div class="lds-ring"><div></div><div></div><div></div><div></div></div>
        </a>

    </button>
    <p>activation for one ads. you have to pay 10$</p>
    <div id="showForm">

    </div>
    <div class="status-payment">
        <?php if(isset($success_payment)): ?>
            <div class="alert alert-success"><?php echo e($success_payment); ?></div>
        <?php endif; ?>
        <?php if(isset($fail_payment)): ?>
            <div class="alert alert-danger"><?php echo e($fail_payment); ?></div>
        <?php endif; ?>
    </div>


</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $("#activation-btn").click(function(e){
            e.preventDefault();
            $.ajax({
                type: 'get',
                url: '<?php echo e(route("get.check.id")); ?>',
                data: {
                    'id' : <?php echo e($id); ?>,
                },
                beforeSend:function(){
                    $('.lds-ring').show();
                },
                success: function(data) {
                   if(data.status == true){
                       $('#showForm').empty().html(data.content);
                       $('.lds-ring').fadeOut(5000);
                   }else{
                       $('#showForm').empty().html('<h3>Something wrong!!!</h3>');
                   }

                },
                error: function(reject) {

                },
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\last-saknni-main\resources\views/property/activation.blade.php ENDPATH**/ ?>