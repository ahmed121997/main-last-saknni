<form method="get" action="<?php echo e(route('main.search')); ?>">
    <div class="container mt-lg-4">
        <div class="row mt-3">
            <div class="col-sm-6 col-md-4 col-lg-3">
                <select name="sell_rent" class="form-control form-control-lg sell-rent">
                    <option <?php if(request('sell_rent') == 'sell'): ?> selected <?php endif; ?> value="sell"><?php echo e(__('property.sell')); ?></option>
                    <option <?php if(request('sell_rent') == 'rent'): ?> selected <?php endif; ?> value="rent"><?php echo e(__('property.rent')); ?></option>
                </select>
            </div>
            <div class="col-sm-6 d-none d-sm-block  d-md-none ">
                <input type="submit" class="btn btn-warning d-block w-100  form-control-lg" value="<?php echo e(__('property.search')); ?>"/>
            </div>

            <div class="col-md-4">
                <select name="gov" id="gov" class="form-control  form-control-lg">
                    <option value="" selected disabled><?php echo e(__('property.choose_governorate')); ?></option>
                    <?php if(isset($govs) && count($govs) > 0): ?>
                        <?php $__currentLoopData = $govs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($gov->id); ?>"><?php echo e($gov->governorate_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>

            <div class="col-md-4">
                <select name="city" id="city" class="form-control  form-control-lg">
                    <option  value="" selected disabled><?php echo e(__('property.choose_city')); ?></option>
                    <optgroup label="all cities in this gov">

                    </optgroup>
                </select>
            </div>

            <div class="col-lg-1 d-none d-lg-block">
                <input type="submit" class="btn btn-warning d-block  form-control-lg" value="<?php echo e(__('property.search')); ?>"/>
            </div>


            <div class="col-sm-6 col-md-4 col-lg-3 type-property">
                <select name="type_property" class="form-control  form-control-lg ">
                    <option value=""><?php echo e(__('property.type_property')); ?></option>
                    <?php if(isset($type_properties) && count($type_properties) > 0): ?>
                        <?php $__currentLoopData = $type_properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(request('type_property') == $type_property->id): ?> selected <?php endif; ?> value="<?php echo e($type_property->id); ?>"><?php echo e($type_property->type); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>
            <div class="col-sm-6 col-md-4 col-lg-2">
                <select name="min_price" class="form-control  form-control-lg select-min-price">


                </select>
            </div>
            <div class="col-sm-6 col-md-4 col-lg-2">
                <select name="max_price" class="form-control  form-control-lg select-max-price">
                </select>
            </div>
            <div  class="col-sm-6 col-md-4 col-lg-2">
                <select name="min_area" class="form-control  form-control-lg">
                    <option value=""><?php echo e(__('property.min_area')); ?></option>
                    <?php for($i = 50 ; $i <=1000; $i = $i +50): ?>
                    <option  <?php if(request('min_area') == $i): ?> selected <?php endif; ?> value="<?php echo e($i); ?>"><?php echo e($i); ?> <?php echo e(__('property.m')); ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-sm-6 col-md-4 col-lg-2">
                <select name="max_area" class="form-control  form-control-lg">
                    <option value=""><?php echo e(__('property.max_area')); ?></option>
                    <?php for($i = 50 ; $i <=1000; $i = $i +50): ?>
                        <option <?php if(request('max_area') == $i): ?> selected <?php endif; ?> value="<?php echo e($i); ?>"><?php echo e($i); ?> <?php echo e(__('property.m')); ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-sm-6 col-md-4 col-lg-3">
                <select name="type_pay" class="form-control  form-control-lg">
                    <option value=""><?php echo e(__('property.type_pay')); ?></option>
                    <?php if(isset($type_payments) && count($type_payments) > 0): ?>
                        <?php $__currentLoopData = $type_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(request('type_pay') == $type_payment->id): ?> selected <?php endif; ?> value="<?php echo e($type_payment->id); ?>"><?php echo e($type_payment->type); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>

            <div class="col-lg-2 d-lg-none d-sm-none d-md-block">
                <input type="submit" class="btn btn-warning d-block w-100  form-control-lg" value="<?php echo e(__('property.search')); ?>"/>
            </div>
        </div>
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\last-saknni-main\resources\views/search/formMainSearch.blade.php ENDPATH**/ ?>