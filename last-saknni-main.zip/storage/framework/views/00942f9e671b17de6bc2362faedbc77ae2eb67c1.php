<?php $__env->startSection('links'); ?>

    <link href="<?php echo e(asset('public/css/addProperty.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- MultiStep Form -->

    <div class="container justify-content-center">
        <div class="row">

            <?php if(Session::has('fail_add')): ?>
                <div class="message text-danger"><?php echo e(Session::get('fail_add')); ?>

                    <i class="fa fa-times-circle-o" aria-hidden="true"></i>
                </div>

            <?php endif; ?>

            <?php if(Session::has('success_add')): ?>
                <div class="message text-success"><?php echo e(Session::get('success_add')); ?>

                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                </div>
            <?php endif; ?>
                <?php if(app()->getLocale() == 'ar'): ?>
                    <div class="col-md-1 col-lg-2"></div>
                    <?php endif; ?>
            <div class="col-sm-12 col-md-10 col-lg-8 offset-md-1 offset-lg-2">
                <form id="msform" method="post" action="<?php echo e(route('store.property')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <!-- progressbar -->
                    <ul id="progressbar">
                        <li class="active"><?php echo e(__('property.get_started')); ?></li>
                        <li><?php echo e(__('property.details_for_property')); ?></li>
                        <li><?php echo e(__('property.your_location')); ?></li>
                        <li><?php echo e(__('property.title')); ?> </li>
                        <li><?php echo e(__('property.property_price')); ?></li>
                        <li><?php echo e(__('property.description')); ?></li>
                    </ul>
                    <!-- start fieldset one -->
                    <fieldset>
                        <h2 class="fs-title"><?php echo e(__('property.get_started_add_your_property')); ?></h2>
                        <h3 class="fs-subtitle"><?php echo e(__('property.build_info_about_your_property')); ?></h3>

                        <label><?php echo e(__('property.type_property')); ?>:</label>
                        <select name="typeProperty" id="typeProperty">
                            <option disabled selected value=""><?php echo e(__('property.choose_type_property')); ?></option>
                            <?php if(isset($type_properties) && count($type_properties) > 0): ?>
                                    <?php $__currentLoopData = $type_properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type_property->id); ?>"><?php echo e($type_property->type); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                        </select>

                        <label><?php echo e(__('property.list_section')); ?>:</label>
                        <select name="listSection" id="listSection">
                            <option value="" selected disabled><?php echo e(__('property.choose_list_section')); ?></option>
                            <option value="sell"><?php echo e(__('property.sell')); ?></option>
                            <option value="rent"><?php echo e(__('property.rent')); ?></option>
                        </select>

                        <label><?php echo e(__('property.area')); ?>:</label>
                        <input type="text" name="area" id="area" placeholder="<?php echo e(__('property.area')); ?>  - 40-5000 "  autoComplete="off"/>
                        <p class="not-valid not-valid-area text-danger" > </p>

                        <label><?php echo e(__('property.view_list')); ?>:</label>
                        <select name="listView" id="listView">
                            <option value="" selected disabled><?php echo e(__('property.choose_listing_view')); ?></option>

                        <?php if(isset($list_views) && count($list_views) > 0): ?>
                                <?php $__currentLoopData = $list_views; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list_view): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list_view->id); ?>"><?php echo e($list_view->list); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>

                        <input  type="button" name="next" class="next action-button btn" value="<?php echo e(__('property.next')); ?>"/>
                    </fieldset>
                        <!-- end fieldset one -->
                        <!-- Start fieldset two -->
                        <fieldset>
                            <h2 class="fs-title"><?php echo e(__('property.details_for_Property')); ?></h2>
                            <h3 class="fs-subtitle"><?php echo e(__('property.tell_us_details_about_your_property')); ?></h3>

                        <label><?php echo e(__('property.floor')); ?>:</label>
                        <input   type="text" name="floor" id="floor" placeholder="<?php echo e(__('property.floor')); ?> 0 - 100" autoComplete="off"/>
                            <p class="not-valid not-valid-floor text-danger" ></p>

                        <label><?php echo e(__('property.rooms')); ?>:</label>
                        <input   type="text" name="rooms" id="rooms" placeholder="<?php echo e(__('property.number_of_rooms')); ?> 1 - 100" autoComplete="off"/>
                            <p class="not-valid not-valid-rooms text-danger" ></p>

                        <label><?php echo e(__('property.bathrooms')); ?>:</label>
                        <input   type="text" name="bathroom" id="bathroom" placeholder="<?php echo e(__('property.number_of_bathrooms')); ?> 1 - 50" autoComplete="off"/>
                            <p class="not-valid not-valid-bathrooms text-danger" ></p>

                        <label><?php echo e(__('property.type_finish')); ?>:</label>
                        <select name="typeFinish" id="typeFinish">
                            <option value="" selected disabled><?php echo e(__('property.choose_type_of_finish')); ?></option>
                            <?php if(isset($type_finishes) && count($type_finishes) > 0): ?>
                                <?php $__currentLoopData = $type_finishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_finish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type_finish->id); ?>"><?php echo e($type_finish->type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>

                        <input type="button" name="previous" class="previous action-button-previous" value="<?php echo e(__('property.previous')); ?>"/>
                        <input type="button" name="next" class="next action-button" value="<?php echo e(__('property.next')); ?>"/>
                    </fieldset>
                    <!-- End fieldset two -->

                    <!-- Start fieldset three -->
                    <fieldset>
                        <h2 class="fs-title"><?php echo e(__('property.your_location')); ?></h2>
                        <h3 class="fs-subtitle"><?php echo e(('property.tell_us_about_location_of_property')); ?></h3>
                        <!--choose your governorate for your property -->

                        <label><?php echo e(__('property.gov')); ?>:</label>
                        <select name="gov" id="gov">
                            <option value="" selected disabled><?php echo e(__('property.choose_governorate')); ?></option>
                            <?php if(isset($govs) && count($govs) > 0): ?>
                                <?php $__currentLoopData = $govs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($gov->id); ?>"><?php echo e($gov->governorate_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>

                        <label><?php echo e(__('property.city')); ?>:</label>
                        <select name="city" id="city">
                            <option  value="" selected disabled><?php echo e(__('property.choose_city')); ?></option>
                            <optgroup label="all cities in this gov">

                            </optgroup>
                        </select>

                        <label><?php echo e(__('property.location')); ?>:</label>
                        <input type="text" name="location" id="landMark" placeholder="<?php echo e(__('property.location_by_details')); ?>" autoComplete="off"/>

                        <input type="button" name="previous" class="previous action-button-previous" value="<?php echo e(__('property.previous')); ?>"/>
                        <input type="button" name="next" class="next action-button" value="<?php echo e(__('property.next')); ?>"/>
                    </fieldset>
                    <!-- End fieldset three -->

                    <!-- Start fieldset four -->
                    <fieldset>
                        <h2 class="fs-title"><?php echo e(__('property.title_your_ads.')); ?></h2>
                        <h3 class="fs-subtitle"><?php echo e(__('property.tell_us_what_Title_you_want_to_be_show')); ?></h3>

                        <label><?php echo e(__('property.title')); ?>:</label>
                        <input type="text" name="title" id="titleAr" placeholder="<?php echo e(__('property.title')); ?>"/>

                        <label><?php echo e(__('property.details')); ?>:</label>
                        <textarea name="details" id="details" placeholder="<?php echo e(__('property.details')); ?>"></textarea>


                        <input type="button" name="previous" class="previous action-button-previous" value="<?php echo e(__('property.previous')); ?>"/>
                        <input type="button" name="next" class="next action-button" value="<?php echo e(__('property.next')); ?>"/>
                    </fieldset>
                    <!-- End fieldset four -->

                    <!-- Start fieldset five -->
                    <fieldset>
                        <h2 class="fs-title"><?php echo e(__('property.property_price')); ?></h2>
                        <h3 class="fs-subtitle"><?php echo e(__('property.tell_us_about_your_price_you_want')); ?></h3>

                        <label><?php echo e(__('property.type_pay')); ?>:</label>
                        <select name="typePay" id="typePay">
                            <option value="" selected disabled><?php echo e(__('property.choose_type_pay')); ?></option>
                            <?php if(isset($type_payments) && count($type_payments) > 0): ?>
                                <?php $__currentLoopData = $type_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type_payment->id); ?>"><?php echo e($type_payment->type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>

                        <label><?php echo e(__('property.price')); ?>:</label>
                        <input type="text" name="price" id="price" placeholder="<?php echo e(__('property.price')); ?>" autocapitalize="off"/>


                        <input type="button" name="previous" class="previous action-button-previous" value="<?php echo e(__('property.previous')); ?>"/>
                        <input type="button" name="next" class="next action-button" value="<?php echo e(__('property.next')); ?>"/>
                    </fieldset>
                    <!-- End fieldset five -->

                    <!-- Start fieldset six -->
                    <fieldset>
                        <h2 class="fs-title"><?php echo e(__('property.description')); ?></h2>
                        <h3 class="fs-subtitle"><?php echo e(__('property.describe_your_property_by_images_or_youtube')); ?></h3>

                        <label><?php echo e(__('property.link_youtube')); ?>:</label>
                        <input type="text" name="linkYoutube" id="linkYoutube" placeholder="<?php echo e(__('property.link_youtube')); ?>"/>


                        <label><?php echo e(__('property.images')); ?>:</label>
                        <input type="file" name="images[]" id="images" multiple placeholder="<?php echo e(__('property.images')); ?>"/>

                        <input type="button" name="previous" class="previous action-button-previous" value="<?php echo e(__('property.previous')); ?>"/>
                        <input type="submit" name="submit" class="submit action-button" value="<?php echo e(__('property.submit')); ?>"/>
                    </fieldset>
                    <!-- End fieldset six -->

                    <div style="margin: 10px auto;width:80%" class="alert alert-danger error"></div>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger mt-3">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><?php echo e($error); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>

                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script  src="<?php echo e(asset('public/js/addProperty.js')); ?>"></script>
<script>
    $("#gov").change(function(){
        $.ajax({
            type: 'post',
            url: '<?php echo e(route("get.cities")); ?>',
            data: {
                '_token' : '<?php echo e(csrf_token()); ?>',
                'id' : this.value,
            },
            success: function(data) {
                let all_opt = "";
                $.each(data,function (key,value) {
                    all_opt += " <option value=" + value.id+ ">" + value.city_name + "</option> ";
                });
                $("#city > optgroup").html(all_opt);
            },
            error: function(reject) {

            },
        });
    });



    $("#listSection").click(function () {
        let type_rent = '<?php echo e(__("property.type_rent")); ?>';
        let daily = '<?php echo e(__("property.daily")); ?>';
        let monthly = '<?php echo e(__("property.monthly")); ?>';
        if($(this).val() === 'rent') {
            if(!$(".type-rent")[0]){
                $(this).after('<label class="type-rent">'+type_rent+':</label>' +
                    '<select name="type_rent" class="type-rent""">' +
                    '<option value="daily">'+daily+'</option>' +
                    '<option value="monthly">'+monthly+'</option>' +
                    '</select>');
            }
        }else{
            $(".type-rent").remove();
        }
    });


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\last-saknni-main\resources\views/property/create.blade.php ENDPATH**/ ?>