<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(URL::to('/')); ?>" target="_blank">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Saknni</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Interface
    </div>

    <!-- Nav Item - Pages Collapse Menu -->
    

     <!-- Users item  -->
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('admin.user')); ?>">
            <i class="fas fa-user fa-2x text-gray"></i>
            <span>Users</span>
        </a>
        <!-- properties item  -->
        <a class="nav-link collapsed" href="<?php echo e(route('admin.property')); ?>">
            <i class="fas fa-home fa-2x text-gray"></i>
            <span>Properties</span>
        </a>

         <!-- logout item  -->
        <a class="nav-link collapsed" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <i class="fas fa-sign-out-alt fa-2x text-gray" ></i>
            <span>Logout</span>
        </a>
        
    </li>


    
    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline mt-3">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>
<!-- End of Sidebar -->
<?php /**PATH C:\xampp\htdocs\last-saknni-main\resources\views/admin/layouts/slidbar.blade.php ENDPATH**/ ?>