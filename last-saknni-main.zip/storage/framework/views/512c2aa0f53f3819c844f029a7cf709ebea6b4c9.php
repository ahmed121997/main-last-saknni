<script>
        $(".icon-love").click(function(){
            $.ajax({
                type: 'post',
                url: '<?php echo e(route("add.favorite")); ?>',
                data: {
                    '_token' : '<?php echo e(csrf_token()); ?>',
                    'id' : this.getAttribute('data'),
                },
                success: function(data) {
                  console.log(data)
                },
                error: function(reject) {

                },
            });
        });

    </script><?php /**PATH C:\xampp\htdocs\last-saknni-main\resources\views/layouts/scriptFavorite.blade.php ENDPATH**/ ?>