<?php
    $locale = App::getLocale();
    $margin = $locale === 'en' ? true : false;
?>
<nav class="navbar navbar-expand-md navbar-dark bg-dark shadow-sm">
    <div class="container">
        <a class="navbar-brand ml-5" href="<?php echo e(url('/')); ?>">
            <span class="s">S</span><span class="ak">Ak</span><span class="nni">nNi</span>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->
            <ul class="navbar-nav <?php echo e($margin ? 'mr-auto': 'ml-auto'); ?>">
                <li class="nav-item <?php echo e(Route::currentRouteNamed('add.property') ? 'active' : ''); ?>">
                    <a class="nav-link"  href="<?php echo e(route('add.property')); ?>"><?php echo e(__('navbar.add_property')); ?></a>
                </li>
                <li class="nav-item <?php echo e(Route::currentRouteNamed('show.all.properties') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('show.all.properties')); ?>"><?php echo e(__('navbar.properties')); ?></a>
                </li>
                <li class="nav-item <?php echo e(Route::currentRouteNamed('index.search') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('index.search')); ?>"><?php echo e(__('navbar.search')); ?></a>
                </li>

                <li class="nav-item <?php echo e(Route::currentRouteNamed('about') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('about')); ?>"><?php echo e(__('navbar.about')); ?></a>
                </li>

            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav <?php echo e($margin ? 'ml-auto': 'mr-auto'); ?>">

                <!-- Authentication Links -->
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('navbar.login')); ?></a>
                    </li>
                    <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('navbar.register')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>

                <!-- Nav Item - Alerts -->
                    

                   

                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
                            <?php echo e(Auth::user()->name); ?>

                        </a>

                        <div class="dropdown-menu dropdown-menu-right " aria-labelledby="navbarDropdown" >
                            <a class="dropdown-item font-weight-bold" href="<?php echo e(route('user.index')); ?>">
                                <?php echo e(__('navbar.profile')); ?>

                            </a>

                            <a class="dropdown-item font-weight-bold" href="<?php echo e(route('user.favorite')); ?>">
                                <?php echo e(__('navbar.favorite')); ?>

                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                <?php echo e(__('navbar.logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>

                <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(app()->getLocale() !== $localeCode): ?>
                        <li  class="nav-item mr-lg-3 ml-lg-3" >
                            <a class="nav-link" rel="alternate" hreflang="<?php echo e($localeCode); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
                                <?php echo e($properties['native']); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\last-saknni-main\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>