<?php if(auth()->guard()->check()): ?>
    <a   href="#"  title="favorite">
        <i data="<?php echo e($id); ?>" class=" <?php if($fav): ?> fas <?php else: ?> far <?php endif; ?> fa-heart fa-lg mt-2
            <?php if(app()->getLocale() == 'en'): ?> float-right mr-2 icon-love <?php else: ?> float-left ml-5 <?php endif; ?>">
        </i>
    </a>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\last-saknni-main\resources\views/property/favorite.blade.php ENDPATH**/ ?>