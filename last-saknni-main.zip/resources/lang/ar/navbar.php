<?php
return [
    'login'=> 'تسجيل دخول',
    'register' => 'تسجيل',
    'add_property' => 'اضافة عقارك',
    'search' => 'بحث',
    'profile' => 'الصفحة الرئسية',
    'logout' => 'تسجيل خروج',
    'properties' => 'عقارات',
    'about' => 'عننا',
    'favorite' => 'المفضلات'
];
