<?php
return [
    'register'=> 'تسجيل',
    'name' => 'الاسم',
    'email' =>'الايميل',
    'phone' => 'رقم الهاتف',
    'password' => 'كلمة السر',
    'confirm_password'=>'تأكيد كلمة السر',
];
