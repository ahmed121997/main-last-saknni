<?php

return [
    'login'=> 'تسجيل دخول',
    'email' => 'البريد الالكتروني',
    'password'=> 'كلمة السر',
    'remember_me'=> 'تذكرني',
    'forget_your_password' => 'هل نسيت كلةالسر؟'
];
