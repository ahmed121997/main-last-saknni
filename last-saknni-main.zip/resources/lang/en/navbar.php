<?php
 return [
     'login'=> 'Login',
     'register' => 'Register',
     'add_property' => 'Add Property',
     'search' => 'Search',
     'profile' => 'Profile',
     'logout' => 'Logout',
     'properties' => 'properties',
     'about' => 'About',
     'favorite'=> 'favorites',
 ];
