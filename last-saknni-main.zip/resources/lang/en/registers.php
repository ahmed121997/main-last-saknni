<?php
return [
  'register'=> 'Register',
    'name' => 'Name',
    'email' =>'E-Mail',
    'phone' => 'Phone',
    'password' => 'Password',
    'confirm_password'=>'Confirm Password',
];
