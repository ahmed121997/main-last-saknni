<?php

return [
    'our_services' => 'Our Services',
    'follow_us' => 'Follow Us',
    'download_app' => 'Download App',
    'saknni_message' =>  'Saknni services allow you to buy or sell a property while providing essential information to help you take one of life’s biggest financial decisions.',


];
